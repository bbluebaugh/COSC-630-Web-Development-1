class Function < ApplicationRecord
	n = 10
	def self.factorial(n)
		if n == 0
			return 1
		else
			return (1..n).inject {|product, n| product * n}
		end
	end


end
