class FunctionsController < ApplicationController
  def factorial
  	@title = "Factorial Calculator"
  	#@fact = function.factorial
  	#function = function.new params[]
  	#@result = function.factorial
  	@content = "This calculator only calculates the factorial for the numbr 10."
  	sum = 1
  	n = 10
  	until n==0
  		sum *= n
  		n -=1
  	end
  	@result = sum
  end

  def fibonacci
  	@fibtitle = "Welcome to the fibonacci calculator"
  	@content = "This calcualtor only calculates the 50th fibonacci number: "
  	num = 50
  	a = 0
  	b = 1
  	num.times do
  		temp = a
  		a = b
  		b = temp + b
  	end
  	#return a
  	@result = a
  end

  def calculator
  	@title = "Welcome to the Calculator function"
  	@content = "This calculator only makes a simple multiplication, division, addition and subtraction"
  	@content2 = "The numbers we will be working with are 10 & 20 ="
  	@addition = "First, we will start with the addition: 10 + 20 ="
  	@subtraction = "Second, we will have the subtraction: 20 - 10 ="
  	@multiplication = "Third, we will have the multiplication: 10 * 20 ="
  	@division = "Finally, we will start have the division: 20 / 10 ="

  	a = 10
  	b = 20
  	@additionresult = a + b
  	@subtractionresult = b - a
  	@multiplicationresult = a * b
  	@divisionresult = b / a

  end

  def sort
  	@title = "Welcome to the Bubble Sort"
  	@content = "This page sorts an array of numbers"

  	list = ['1', '50', '17', '-200', '500', '26']
  	@original = "The original order of the numbers are: 1, 50, 17, -200, 500, 26"
  	return list if list.size <= 1 #already sorted
  	swapped = true
  	while swapped do
  		swapped = false
  		0.upto(list.size-2) do |i|#swap values
  			if list[i] > list[i+1]
  				list[i], list[i+1] = list[i+1], list[i] #swap values
  				swapped = true
  			end
  		end
  	end
  	@result = list
  end
end
