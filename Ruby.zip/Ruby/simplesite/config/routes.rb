Rails.application.routes.draw do
  get 'functions/factorial', as: 'factorial'

  get 'functions/fibonacci', as: 'fibonacci'

  get 'functions/calculator', as: 'calculator'

  get 'functions/sort', as: 'sort'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root 'posts#index', as: 'home'

  get 'about' => 'pages#about', as: 'about'

  #get 'factorial' => 'posts#factorial', as 'factorial'

  resources :posts


end
