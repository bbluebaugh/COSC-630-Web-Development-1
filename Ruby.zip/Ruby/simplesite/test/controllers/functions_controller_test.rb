require 'test_helper'

class FunctionsControllerTest < ActionDispatch::IntegrationTest
  test "should get factorial" do
    get functions_factorial_url
    assert_response :success
  end

  test "should get fibonacci" do
    get functions_fibonacci_url
    assert_response :success
  end

  test "should get calculator" do
    get functions_calculator_url
    assert_response :success
  end

  test "should get sort" do
    get functions_sort_url
    assert_response :success
  end

end
