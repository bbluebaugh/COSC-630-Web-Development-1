require 'test_helper'

class FunctionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
