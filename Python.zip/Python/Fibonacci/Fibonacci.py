#Fibonacci sequence of numbers from user input.
#@author Brian Bluebaugh    @Version 6/25/2018


print("Enter the number of fibonacci numbers you want: ")
nterms = int(input())

def fibonacciRecursive(n):
    if n <= 1:
        return n
    else:
        return(fibonacciRecursive(n-1) + fibonacciRecursive(n-2))
#nterms = 10


print("Fibonacci sequence: ")
for i in range(nterms):
    print(fibonacciRecursive(i))